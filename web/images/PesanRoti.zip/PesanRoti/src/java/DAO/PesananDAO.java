/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.PesananModel;

/**
 *
 * @author afriliadvi
 */
public class PesananDAO {
    
    public void insertData(PesananModel data){
        
        try{
            Connection conn = new DBConnection().setConnection();
            PreparedStatement ps = conn.prepareStatement("insert into pemesanan(NAMA_PEMESAN, ALAMAT, JENIS_ROTI, JLH_PESAN, TOTAL_BAYAR) values(?,?,?,?,?)");
            ps.setString(1, data.getNama());
            ps.setString(2, data.getAlamat());
            ps.setString(3, data.getJenisRoti());
            ps.setInt(4, data.getJlhRoti());
            ps.setInt(5, data.getTotal());           
            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
    
    public List<PesananModel> showAllData() throws SQLException {

	List<PesananModel> pesanan = new ArrayList<>();
	try {
            Connection conn = new DBConnection().setConnection();
            PreparedStatement ps = conn.prepareStatement("select * from pemesanan");
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                PesananModel u = new PesananModel();
                u.setId(rs.getInt("ID_PESAN"));
                u.setNama(rs.getString("NAMA_PEMESAN"));
                u.setAlamat(rs.getString("ALAMAT"));
                u.setJenisRoti(rs.getString("JENIS_ROTI"));
                u.setJlhRoti(rs.getInt("JLH_PESAN"));
                u.setTotal(rs.getInt("TOTAL_BAYAR"));
                pesanan.add(u);
            } 
           }catch (Exception e) {
                System.out.println(e);
            }
        return pesanan;
    }
    
    public static PesananModel getDataById(int id) {
        PesananModel u = null;
        try {
            Connection conn = new DBConnection().setConnection();
            PreparedStatement ps = conn.prepareStatement("select * from pemesanan where ID_PESAN=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                u = new PesananModel();
                u.setId(rs.getInt("ID_PESAN"));
                u.setNama(rs.getString("NAMA_PEMESAN"));
                u.setAlamat(rs.getString("ALAMAT"));
                u.setJenisRoti(rs.getString("JENIS_ROTI"));
                u.setJlhRoti(rs.getInt("JLH_PESAN"));
                u.setTotal(rs.getInt("TOTAL_BAYAR"));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return u;
    }
    
     public void editData(PesananModel data){
        
        try{
            Connection conn = new DBConnection().setConnection();
            PreparedStatement ps = conn.prepareStatement("update pemesanan set NAMA_PEMESAN=?,ALAMAT=?,JENIS_ROTI=?,JLH_PESAN=?,TOTAL_BAYAR=? where ID_PESAN=?");
            ps.setString(1, data.getNama());
            ps.setString(2, data.getAlamat());
            ps.setString(3, data.getJenisRoti());
            ps.setInt(4, data.getJlhRoti());
            ps.setInt(5, data.getTotal());
            ps.setInt(6, data.getId());
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
     
    public void deleteData(int id) {
        try {
            Connection conn = new DBConnection().setConnection();
            PreparedStatement ps = conn.prepareStatement("delete from pemesanan where ID_PESAN=?");
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }

    }
    
}
