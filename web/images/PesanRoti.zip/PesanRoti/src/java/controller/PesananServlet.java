/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;

import DAO.PesananDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.PesananModel;

/**
 *
 * @author afriliadvi
 */
public class PesananServlet extends HttpServlet {

     private PesananDAO dao; 
    
    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        dao = new PesananDAO();
        
        String action = request.getServletPath();

		try {
			switch (action) {
			case "/baru":
				formInputPesanan(request, response);
				break;
			case "/tambah":
				insertPesanan(request, response);
				break;
                        case "/ubah":
				editPesanan(request, response);
				break;
                        case "/hapus":
				deletePesanan(request, response);
				break;
			}
		} catch (SQLException ex) {
			throw new ServletException(ex);
		}
    }

    private void formInputPesanan(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
	RequestDispatcher dp = request.getRequestDispatcher("formPesan.jsp");
	dp.forward(request, response);
    }
        
    private void insertPesanan(HttpServletRequest request, HttpServletResponse response) 
		throws SQLException, IOException, ServletException {
	    
        String nama  = request.getParameter("nama");
        String alamat  = request.getParameter("alamat");
        String jenisRoti  = request.getParameter("jenis-roti");
        int jlhRoti  = Integer.parseInt(request.getParameter("jlh-roti"));
        int total = jlhRoti*10000;
        
        PesananModel pesanan = new PesananModel(nama, alamat, jenisRoti, jlhRoti, total);
        dao.insertData(pesanan);
        
        request.setAttribute("data", pesanan);
        
        RequestDispatcher dp = request.getRequestDispatcher("lihatData.jsp");
        dp.forward(request, response);
    }
    
    private void editPesanan(HttpServletRequest request, HttpServletResponse response) 
		throws SQLException, IOException, ServletException {
	    
        int id = Integer.parseInt(request.getParameter("id"));
        String nama  = request.getParameter("nama");
        String alamat  = request.getParameter("alamat");
        String jenisRoti  = request.getParameter("jenis-roti");
        int jlhRoti  = Integer.parseInt(request.getParameter("jlh-roti"));
        int total = jlhRoti*10000;
        
        PesananModel pesanan = new PesananModel(id, nama, alamat, jenisRoti, jlhRoti, total);
        dao.editData(pesanan);
        
        request.setAttribute("data", pesanan);
        
        RequestDispatcher dp = request.getRequestDispatcher("lihatData.jsp");
        dp.forward(request, response);
    }
    
    private void deletePesanan(HttpServletRequest request, HttpServletResponse response) 
		throws SQLException, IOException {
	int id = Integer.parseInt(request.getParameter("id"));
	dao.deleteData(id);
        response.sendRedirect("index.jsp");
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
