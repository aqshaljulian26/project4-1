/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

/**
 *
 * @author afriliadvi
 */
public class PesananModel {
    
    private String nama;
    private String alamat;
    private String jenisRoti;
    private int id;
    private int jlhRoti;
    private int total;
    
    public PesananModel(String nama, String alamat, String jenis, int jlh, int total) {
        this.nama=nama;
        this.alamat=alamat;
        this.jenisRoti=jenis;
        this.jlhRoti=jlh;
        this.total=total;
    }
    
    public PesananModel(int id, String nama, String alamat, String jenis, int jlh, int total) {
        this.id=id;
        this.nama=nama;
        this.alamat=alamat;
        this.jenisRoti=jenis;
        this.jlhRoti=jlh;
        this.total=total;
    }

    public PesananModel() {
       
    }

    /**
     * @return the nama
     */
    public String getNama() {
        return nama;
    }

    /**
     * @param nama the nama to set
     */
    public void setNama(String nama) {
        this.nama = nama;
    }

    /**
     * @return the alamat
     */
    public String getAlamat() {
        return alamat;
    }

    /**
     * @param alamat the alamat to set
     */
    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    /**
     * @return the jenisRoti
     */
    public String getJenisRoti() {
        return jenisRoti;
    }

    /**
     * @param jenisRoti the jenisRoti to set
     */
    public void setJenisRoti(String jenisRoti) {
        this.jenisRoti = jenisRoti;
    }

    /**
     * @return the jlhRoti
     */
    public int getJlhRoti() {
        return jlhRoti;
    }

    /**
     * @param jlhRoti the jlhRoti to set
     */
    public void setJlhRoti(int jlhRoti) {
        this.jlhRoti = jlhRoti;
    }

    /**
     * @return the total
     */
    public int getTotal() {
        return total;
    }

    /**
     * @param total the total to set
     */
    public void setTotal(int total) {
        this.total = total;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }
}
